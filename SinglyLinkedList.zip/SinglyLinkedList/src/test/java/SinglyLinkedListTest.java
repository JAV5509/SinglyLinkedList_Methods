import static org.junit.jupiter.api.Assertions.*;

class SinglyLinkedListTest {

    @org.junit.jupiter.api.Test
    void testAppend() {
        SinglyLinkedList sll = new SinglyLinkedList();
        sll = sll.append(1);
        assertEquals("1 --> NULL", sll.toString());
        sll = sll.append(2);
        sll = sll.append(3);
        assertEquals("1 --> 2 --> 3 --> NULL", sll.toString());
        }
    @org.junit.jupiter.api.Test
    void testContains() {
        SinglyLinkedList sll = new SinglyLinkedList();
        sll = sll.append(1);
        sll = sll.append(2);
        sll = sll.append(3);
        assertTrue(sll.contains(3));
        }
    @org.junit.jupiter.api.Test
    void testdelete() {
        SinglyLinkedList sll = new SinglyLinkedList();
        sll = sll.append(1);
        sll = sll.append(2);
        sll = sll.append(3);
        sll = sll.append(4);
      //  sll = sll.delete(1);
       // assertEquals("2 --> 3 --> NULL", sll.toString());
        sll = sll.delete(3);
        assertEquals("1 --> 2 --> 4 --> NULL", sll.toString());
    }

    }