public class Node <T> {
    protected T data;
    Node next;

    public Node(T data){
        this.data = data;
        this.next = null;
    }
}
