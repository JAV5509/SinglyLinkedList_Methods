public class SinglyLinkedList <T> {
    Node<T> head;
    public SinglyLinkedList(){
        this.head = null;
        }

    public SinglyLinkedList append(T data){
        //appending a node at the end of the linked list
        Node<T> toAppend = new Node(data);
        if(this.head == null){
            this.head = toAppend;
            }
        else{
            Node<T> tempNode = this.head;
            while(tempNode.next != null){
                tempNode = tempNode.next;
            }
            tempNode.next = toAppend;
        }
        return this;
        }
    public boolean contains(T data){
        //Checking the elements of a list if includes a node with 'data'
        if(this.head == null) return false;
        else {
            Node<T> tempNode = this.head;
            while (tempNode != null) {
                if (tempNode.data == data) return true;
                else tempNode = tempNode.next;
            }
        }
        return false;
        }
    public SinglyLinkedList delete(T data) {
        //Delete the element of a list if includes a node with 'data'
        if (this.head == null) return this;
        else {
            if (this.contains(data)) {
                Node tempNode = head;
                if (head.data == data) head = head.next;
                else {
                    while (tempNode.next != null) {
                        if (tempNode.next.data == data)
                            tempNode.next = tempNode.next.next;
                        else tempNode = tempNode.next;
                    }
                }
            }
        }
        return this;
    }
    @Override
    public String toString(){
        StringBuilder stb = new StringBuilder();
        if(this.head == null){
            stb.append("");
            }
        else {
            Node toPrint = head;
            while (toPrint != null) {
                stb = stb.append(toPrint.data);
                stb = stb.append(" --> ");
                toPrint = toPrint.next;
            }
        }
        stb = stb.append("NULL");
        return stb.toString();
    }

}
